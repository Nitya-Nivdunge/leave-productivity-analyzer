import axios from 'axios';

const API_BASE_URL = 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// File upload with progress tracking
export const uploadAttendance = async (file, month, year, override = false) => {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('month', month);
  formData.append('year', year);
  formData.append('override', override);

  try {
    const response = await api.post('/upload', formData, {
      headers: {
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  } catch (error) {
    // Handle duplicate key error specifically
    if (error.response?.data?.error?.includes('duplicate key') || 
        error.response?.data?.error?.includes('E11000')) {
      throw { 
        status: 409, 
        message: 'Attendance record already exists for this employee and date. Check "Override" to replace existing data.' 
      };
    }
    throw error.response?.data || error;
  }
};

// Get dashboard data
export const getDashboardData = async () => {
  try {
    const response = await api.get('/dashboard');
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Get monthly data
export const getMonthlyData = async (year, month) => {
  try {
    const response = await api.get(`/month/${year}/${month}`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Get all months
export const getAllMonths = async () => {
  try {
    const response = await api.get('/months');
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Get employees
export const getEmployees = async () => {
  try {
    const response = await api.get('/employees');
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Health check
export const healthCheck = async () => {
  try {
    const response = await api.get('/health');
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Get overall insights
export const getOverallInsights = async (year) => {
  try {
    const response = await api.get(`/overall/${year}`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Get year comparison data
export const getYearComparison = async () => {
  try {
    const response = await api.get('/year-comparison');
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Get all employees productivity
export const getAllEmployeesProductivity = async (year) => {
  try {
    const response = await api.get(`/employees/productivity/${year}`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

// Get workforce daily breakdown
export const getWorkforceDailyBreakdown = async (year, month) => {
  try {
    const response = await api.get(`/workforce/${year}/${month}`);
    return response.data;
  } catch (error) {
    throw error.response?.data || error;
  }
};

export default api;