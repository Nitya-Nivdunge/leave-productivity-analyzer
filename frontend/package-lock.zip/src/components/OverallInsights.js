import React from 'react';

const OverallInsights = () => {
  return (
    <div className="bg-white rounded-lg shadow-sm border p-6 text-center">
      <h3 className="text-lg font-semibold text-gray-800 mb-3">Overall Insights</h3>
      <p className="text-sm text-gray-600">
        Upload data or select a month to see overall insights, productivity charts, and workforce analytics.
      </p>
    </div>
  );
};

export default OverallInsights;