import React, { useState, useEffect } from 'react';
import { Toaster, toast } from 'react-hot-toast';
import FileUpload from './FileUpload';
import Statistics from './Statistics';
import AttendanceTable from './AttendanceTable';
import ProductivityChart from './Charts/ProductivityChart';
import CalendarView from './CalendarView';
import OverallProductivityChart from './OverallProductivityChart';
import YearComparisonChart from './YearComparisonChart';
import WorkforceCalendarView from './WorkforceCalendarView';
import EmployeeSearch from './EmployeeSearch';
import { getMonthlyData, getOverallInsights, getYearComparison, getAllEmployeesProductivity, getWorkforceDailyBreakdown } from '../services/api';

const Dashboard = () => {
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear());
  const [selectedMonth, setSelectedMonth] = useState(new Date().getMonth() + 1);
  const [monthlyData, setMonthlyData] = useState(null);
  const [overallData, setOverallData] = useState(null);
  const [yearComparisonData, setYearComparisonData] = useState(null);
  const [allEmployeesProductivity, setAllEmployeesProductivity] = useState(null);
  const [workforceData, setWorkforceData] = useState(null);
  const [selectedEmployee, setSelectedEmployee] = useState(null);
  const [loading, setLoading] = useState(false);
  const [activePage, setActivePage] = useState('overall-insights');
  const [uploadSuccess, setUploadSuccess] = useState(false);
  const [employeeSearchTerm, setEmployeeSearchTerm] = useState('');
  const [breakdownView, setBreakdownView] = useState('calendar');
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const [employeeStats, setEmployeeStats] = useState(null);

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  useEffect(() => {
    loadAllData();
  }, [selectedYear, selectedMonth]);

  useEffect(() => {
    if (uploadSuccess) {
      const timer = setTimeout(() => {
        setUploadSuccess(false);
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [uploadSuccess]);

  const loadAllData = async () => {
    try {
      setLoading(true);
      
      // Load monthly data
      await loadMonthlyData(selectedYear, selectedMonth);
      
      // Load overall insights
      const overall = await getOverallInsights(selectedYear);
      setOverallData(overall);
      
      // Load year comparison
      const comparison = await getYearComparison();
      setYearComparisonData(comparison);
      
      // Load all employees productivity
      const productivity = await getAllEmployeesProductivity(selectedYear);
      setAllEmployeesProductivity(productivity);
      
      // Load workforce data
      const workforce = await getWorkforceDailyBreakdown(selectedYear, selectedMonth);
      setWorkforceData(workforce);
      
    } catch (error) {
      console.error('Error loading data:', error);
      if (error.status !== 404) {
        toast.error('Failed to load data');
      }
    } finally {
      setLoading(false);
    }
  };

  const loadMonthlyData = async (year, month) => {
    try {
      const data = await getMonthlyData(year, month);
      setMonthlyData(data);
      
      // Update filtered employees list
      if (data.statistics && data.statistics.length > 0) {
        const sortedEmployees = [...data.statistics]
          .sort((a, b) => a.employeeName.localeCompare(b.employeeName));
        setFilteredEmployees(sortedEmployees);
        
        // Calculate employee stats for overall insights
        const stats = {
          totalEmployees: sortedEmployees.length,
          avgProductivity: sortedEmployees.reduce((sum, emp) => sum + (emp.productivity || 0), 0) / sortedEmployees.length,
          avgHours: sortedEmployees.reduce((sum, emp) => sum + (emp.totalWorkedHours || 0), 0) / sortedEmployees.length,
          totalLeaves: sortedEmployees.reduce((sum, emp) => sum + (emp.leavesTaken || 0), 0),
          totalHours: sortedEmployees.reduce((sum, emp) => sum + (emp.totalWorkedHours || 0), 0),
          employees: sortedEmployees
        };
        setEmployeeStats(stats);
        
        // If employee search term exists, try to find matching employee
        if (employeeSearchTerm.trim() !== '') {
          const found = sortedEmployees.find(emp => 
            emp.employeeName.toLowerCase().includes(employeeSearchTerm.toLowerCase())
          );
          if (found) {
            setSelectedEmployee(found);
          } else {
            setSelectedEmployee(null);
          }
        }
      } else {
        setFilteredEmployees([]);
        setSelectedEmployee(null);
        setEmployeeStats(null);
      }
    } catch (error) {
      if (error.error === 'No data found') {
        setMonthlyData(null);
        setFilteredEmployees([]);
        setSelectedEmployee(null);
        setEmployeeStats(null);
      }
    }
  };

  const handleUploadSuccess = (result) => {
    setUploadSuccess(true);
    loadAllData();
  };

  const handleEmployeeSearch = (searchTerm) => {
    setEmployeeSearchTerm(searchTerm);
    
    if (!filteredEmployees || filteredEmployees.length === 0) {
      toast.error('No employees available for this month');
      return;
    }
    
    const found = filteredEmployees.find(emp => 
      emp.employeeName.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    if (found) {
      setSelectedEmployee(found);
      setActivePage('employee-detail');
    } else {
      setSelectedEmployee(null);
      toast.error(`No employee found matching "${searchTerm}"`);
    }
  };

  const clearEmployeeSearch = () => {
    setEmployeeSearchTerm('');
    setSelectedEmployee(null);
    setActivePage('overall-insights');
  };

  // Overall Insights Component
  const OverallInsights = () => {
    return (
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <h2 className="text-lg font-semibold text-gray-800">
            Overall Insights - {selectedYear}
          </h2>
          <div className="text-sm text-gray-500">
            {monthNames[selectedMonth - 1]} {selectedYear}
          </div>
        </div>
        
        {/* Employee Stats Cards */}
        {employeeStats && (
          <div className="grid grid-cols-4 gap-3">
            <div className="bg-white rounded-lg shadow-sm border p-3">
              <h3 className="text-xs font-semibold text-gray-600 mb-2">Total Employees</h3>
              <div className="text-2xl font-bold text-gray-800">
                {employeeStats.totalEmployees}
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm border p-3">
              <h3 className="text-xs font-semibold text-gray-600 mb-2">Avg Productivity</h3>
              <div className={`text-2xl font-bold ${employeeStats.avgProductivity >= 80 ? 'text-green-600' : employeeStats.avgProductivity >= 70 ? 'text-yellow-600' : 'text-red-600'}`}>
                {employeeStats.avgProductivity.toFixed(1)}%
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm border p-3">
              <h3 className="text-xs font-semibold text-gray-600 mb-2">Avg Hours</h3>
              <div className="text-2xl font-bold text-blue-600">
                {employeeStats.avgHours.toFixed(1)}h
              </div>
            </div>
            <div className="bg-white rounded-lg shadow-sm border p-3">
              <h3 className="text-xs font-semibold text-gray-600 mb-2">Total Leaves</h3>
              <div className="text-2xl font-bold text-red-600">
                {employeeStats.totalLeaves}
              </div>
            </div>
          </div>
        )}
        
        {/* Employee List Table */}
        {employeeStats && employeeStats.employees.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border">
            <div className="px-4 py-3 border-b border-gray-200">
              <h3 className="text-sm font-semibold text-gray-800">Employees ({employeeStats.employees.length})</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Employee</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Productivity</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Worked Hours</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Leaves</th>
                    <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {employeeStats.employees.map((emp, index) => (
                    <tr 
                      key={index}
                      className="hover:bg-gray-50 cursor-pointer"
                      onClick={() => {
                        setSelectedEmployee(emp);
                        setActivePage('employee-detail');
                      }}
                    >
                      <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900">
                        {emp.employeeName}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-0.5 text-xs font-medium rounded-full ${emp.productivity >= 90 ? 'bg-green-100 text-green-800' : emp.productivity >= 70 ? 'bg-blue-100 text-blue-800' : 'bg-red-100 text-red-800'}`}>
                          {emp.productivity.toFixed(1)}%
                        </span>
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">
                        {emp.totalWorkedHours.toFixed(1)}h
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-900">
                        <span className={emp.leavesTaken > emp.leavesAllowed ? 'text-red-600 font-medium' : ''}>
                          {emp.leavesTaken}/{emp.leavesAllowed}
                        </span>
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-0.5 text-xs font-medium rounded-full ${
                          emp.leavesTaken > emp.leavesAllowed ? 'bg-red-100 text-red-800' :
                          emp.leavesTaken === emp.leavesAllowed ? 'bg-yellow-100 text-yellow-800' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {emp.leavesTaken > emp.leavesAllowed ? 'Over Limit' :
                           emp.leavesTaken === emp.leavesAllowed ? 'Limit Reached' :
                           'Within Limit'}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
        
        {/* Overall Productivity Chart */}
        {allEmployeesProductivity && allEmployeesProductivity.employees && allEmployeesProductivity.employees.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-4">Overall Productivity Distribution</h3>
            <OverallProductivityChart data={allEmployeesProductivity} />
          </div>
        )}
        
        {/* Year Comparison */}
        {yearComparisonData && yearComparisonData.length > 0 && (
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-4">Year Comparison</h3>
            <YearComparisonChart data={yearComparisonData} />
          </div>
        )}
        
        {/* Workforce Calendar */}
        {workforceData && (
          <div className="bg-white rounded-lg shadow-sm border p-4">
            <h3 className="text-sm font-semibold text-gray-800 mb-4">
              Workforce Calendar - {monthNames[selectedMonth - 1]} {selectedYear}
            </h3>
            <WorkforceCalendarView 
              data={workforceData} 
              year={selectedYear} 
              month={selectedMonth} 
            />
          </div>
        )}
      </div>
    );
  };

  if (loading && !monthlyData && !overallData) {
    return (
      <div className="h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gray-50 overflow-hidden flex flex-col">
      <Toaster 
        position="top-right"
        toastOptions={{
          duration: 3000,
          style: {
            background: '#363636',
            color: '#fff',
            fontSize: '14px',
          },
        }}
      />
      
      {/* Header - Centered */}
      <header className="bg-white shadow py-3 px-6">
        <div className="flex justify-center items-center">
          <h1 className="text-xl font-bold text-gray-900 text-center">
            Leave & Productivity Analyzer
          </h1>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex flex-1 overflow-hidden">
        
        {/* Left Panel - Compact */}
        <div className="w-64 bg-white border-r border-gray-200 p-3 flex flex-col space-y-3 overflow-y-auto">
          
          {/* Filters */}
          <div className="space-y-2">
            <h3 className="text-xs font-semibold text-gray-700 uppercase tracking-wider">Filters</h3>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Year</label>
                <select
                  value={selectedYear}
                  onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                  className="w-full border border-gray-300 rounded p-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                >
                  {[2025, 2024, 2023, 2022].map(year => (
                    <option key={year} value={year}>{year}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Month</label>
                <select
                  value={selectedMonth}
                  onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                  className="w-full border border-gray-300 rounded p-1.5 text-xs focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
                >
                  <option value="1">Jan</option>
                  <option value="2">Feb</option>
                  <option value="3">Mar</option>
                  <option value="4">Apr</option>
                  <option value="5">May</option>
                  <option value="6">Jun</option>
                  <option value="7">Jul</option>
                  <option value="8">Aug</option>
                  <option value="9">Sep</option>
                  <option value="10">Oct</option>
                  <option value="11">Nov</option>
                  <option value="12">Dec</option>
                </select>
              </div>
            </div>
            
            {/* Employee Search */}
            <div className="pt-1">
              <label className="block text-xs font-medium text-gray-600 mb-1">Search Employee</label>
              <EmployeeSearch
                employees={filteredEmployees.map(emp => emp.employeeName)}
                onSelect={handleEmployeeSearch}
              />
            </div>
          </div>

          {/* File Upload */}
          <div className="pt-1">
            <FileUpload 
              selectedYear={selectedYear}
              selectedMonth={selectedMonth}
              onUploadSuccess={handleUploadSuccess}
            />
          </div>

          {/* Upload Success Message */}
          {uploadSuccess && (
            <div className="bg-green-50 border border-green-200 rounded p-2 animate-fade-in">
              <div className="flex items-center">
                <svg className="h-4 w-4 text-green-400 mr-1.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
                <p className="text-xs text-green-800">
                  File uploaded! Data updated.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          
          {/* Navigation */}
          <div className="bg-white border-b border-gray-200">
            <div className="flex">
              <button
                onClick={() => {
                  setActivePage('overall-insights');
                  clearEmployeeSearch();
                }}
                className={`px-4 py-2 text-xs font-medium transition-colors ${
                  activePage === 'overall-insights' 
                    ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50' 
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                }`}
              >
                Overall Insights
              </button>
              {selectedEmployee && (
                <>
                  <button
                    onClick={() => setActivePage('employee-detail')}
                    className={`px-4 py-2 text-xs font-medium transition-colors ${
                      activePage === 'employee-detail' 
                        ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50' 
                        : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    Employee Dashboard
                  </button>
                  <button
                    onClick={() => setActivePage('productivity')}
                    className={`px-4 py-2 text-xs font-medium transition-colors ${
                      activePage === 'productivity' 
                        ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50' 
                        : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    Productivity Analysis
                  </button>
                  <button
                    onClick={() => setActivePage('daily-breakdown')}
                    className={`px-4 py-2 text-xs font-medium transition-colors ${
                      activePage === 'daily-breakdown' 
                        ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50' 
                        : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    Daily Breakdown
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Page Content */}
          <div className="flex-1 overflow-y-auto p-3">
            
            {/* Overall Insights Page */}
            {activePage === 'overall-insights' && <OverallInsights />}

            {/* Employee Detail Page */}
            {activePage === 'employee-detail' && selectedEmployee && (
              <div className="space-y-3">
                <div className="bg-white rounded-lg shadow-sm border p-3">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="text-sm font-semibold text-gray-800">
                      Employee Dashboard: {selectedEmployee.employeeName}
                    </h3>
                    <button
                      onClick={clearEmployeeSearch}
                      className="text-xs text-gray-500 hover:text-gray-700 flex items-center"
                    >
                      <svg className="w-3 h-3 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                      </svg>
                      Back to All Employees
                    </button>
                  </div>
                  <Statistics data={selectedEmployee} />
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <ProductivityChart 
                    data={selectedEmployee} 
                    year={selectedYear}
                    month={selectedMonth}
                  />
                  
                  <div className="bg-white rounded-lg shadow-sm border p-3">
                    <h3 className="text-sm font-semibold mb-3">Leave Status</h3>
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between mb-1 text-xs">
                          <span className="text-gray-700">Leaves Used</span>
                          <span className="font-medium">
                            {selectedEmployee.leavesTaken} / {selectedEmployee.leavesAllowed}
                          </span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className={`h-1.5 rounded-full transition-all duration-300 ${
                              selectedEmployee.leavesTaken > selectedEmployee.leavesAllowed
                                ? 'bg-red-600'
                                : selectedEmployee.leavesTaken === selectedEmployee.leavesAllowed
                                ? 'bg-yellow-500'
                                : 'bg-green-600'
                            }`}
                            style={{ 
                              width: `${Math.min((selectedEmployee.leavesTaken / selectedEmployee.leavesAllowed) * 100, 100)}%` 
                            }}
                          />
                        </div>
                      </div>
                      <div className="text-xs">
                        <p className="text-gray-600">Allowed leaves per month: {selectedEmployee.leavesAllowed}</p>
                        <p className={`mt-1 font-medium ${
                          selectedEmployee.leavesTaken > selectedEmployee.leavesAllowed
                            ? 'text-red-600'
                            : selectedEmployee.leavesTaken === selectedEmployee.leavesAllowed
                            ? 'text-yellow-600'
                            : 'text-green-600'
                        }`}>
                          Status: {selectedEmployee.leavesTaken > selectedEmployee.leavesAllowed
                            ? 'Exceeded limit'
                            : selectedEmployee.leavesTaken === selectedEmployee.leavesAllowed
                            ? 'Limit reached'
                            : 'Within limit'
                          }
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Productivity Page */}
            {activePage === 'productivity' && selectedEmployee && (
              <div className="space-y-3">
                <ProductivityChart 
                  data={selectedEmployee} 
                  year={selectedYear}
                  month={selectedMonth}
                  detailed={true} 
                />
              </div>
            )}

            {/* Daily Breakdown Page */}
            {activePage === 'daily-breakdown' && selectedEmployee && (
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <h3 className="text-sm font-semibold text-gray-800">
                    Daily Breakdown - {selectedEmployee.employeeName}
                  </h3>
                  <div className="flex items-center space-x-2">
                    <span className="text-xs text-gray-600">View:</span>
                    <div className="inline-flex rounded-md shadow-sm" role="group">
                      <button
                        type="button"
                        onClick={() => setBreakdownView('calendar')}
                        className={`px-3 py-1 text-xs font-medium rounded-l transition-colors ${
                          breakdownView === 'calendar' 
                            ? 'bg-blue-100 text-blue-700 border border-blue-300' 
                            : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                        }`}
                      >
                        Calendar
                      </button>
                      <button
                        type="button"
                        onClick={() => setBreakdownView('table')}
                        className={`px-3 py-1 text-xs font-medium rounded-r transition-colors ${
                          breakdownView === 'table' 
                            ? 'bg-blue-100 text-blue-700 border border-blue-300' 
                            : 'bg-white text-gray-700 hover:bg-gray-50 border border-gray-300'
                        }`}
                      >
                        Table
                      </button>
                    </div>
                  </div>
                </div>

                {breakdownView === 'calendar' ? (
                  <CalendarView 
                    year={selectedYear}
                    month={selectedMonth}
                    dailyBreakdown={selectedEmployee.dailyBreakdown || []}
                    employeeName={selectedEmployee.employeeName}
                  />
                ) : (
                  <AttendanceTable data={selectedEmployee} />
                )}
              </div>
            )}

            {/* No Employee Selected */}
            {activePage !== 'overall-insights' && !selectedEmployee && (
              <div className="bg-white rounded-lg shadow-sm border p-6 text-center">
                <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <h3 className="mt-4 text-sm font-medium text-gray-900">No Employee Selected</h3>
                <p className="mt-1 text-xs text-gray-500">
                  Search for an employee or click on an employee name to view details
                </p>
                <button
                  onClick={() => setActivePage('overall-insights')}
                  className="mt-4 px-3 py-1.5 text-xs bg-blue-50 text-blue-600 rounded hover:bg-blue-100 transition-colors"
                >
                  View Overall Insights
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;