import React from 'react';
import { Bar } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js';

// Register Chart components
ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const YearComparisonChart = ({ data }) => {
  if (!data || data.length === 0) {
    return (
      <div className="text-center py-4">
        <p className="text-sm text-gray-500">No comparison data available</p>
      </div>
    );
  }

  const chartData = {
    labels: data.map(item => item.year),
    datasets: [
      {
        label: 'Avg Productivity (%)',
        data: data.map(item => item.avgProductivity || 0),
        backgroundColor: 'rgba(59, 130, 246, 0.7)',
        borderColor: 'rgb(59, 130, 246)',
        borderWidth: 1,
        yAxisID: 'y',
      },
      {
        label: 'Avg Hours',
        data: data.map(item => item.avgHours || 0),
        backgroundColor: 'rgba(34, 197, 94, 0.7)',
        borderColor: 'rgb(34, 197, 94)',
        borderWidth: 1,
        yAxisID: 'y1',
      },
      {
        label: 'Avg Leaves/Employee',
        data: data.map(item => item.avgLeavesPerEmployee || 0),
        backgroundColor: 'rgba(239, 68, 68, 0.7)',
        borderColor: 'rgb(239, 68, 68)',
        borderWidth: 1,
        yAxisID: 'y',
      }
    ]
  };

  const options = {
    responsive: true,
    maintainAspectRatio: false,
    interaction: {
      mode: 'index',
      intersect: false,
    },
    plugins: {
      legend: {
        position: 'top',
        labels: {
          boxWidth: 12,
          padding: 15,
          font: {
            size: 11
          },
          usePointStyle: true,
        }
      },
      tooltip: {
        callbacks: {
          label: function(context) {
            let label = context.dataset.label || '';
            if (label.includes('Productivity')) {
              label += ': ' + context.parsed.y.toFixed(1) + '%';
            } else if (label.includes('Hours')) {
              label += ': ' + context.parsed.y.toFixed(1) + 'h';
            } else {
              label += ': ' + context.parsed.y.toFixed(1);
            }
            return label;
          }
        }
      }
    },
    scales: {
      x: {
        grid: {
          display: false
        }
      },
      y: {
        type: 'linear',
        display: true,
        position: 'left',
        title: {
          display: true,
          text: 'Productivity (%) & Leaves'
        },
        ticks: {
          callback: function(value) {
            return value + (this.scale.id === 'y' ? '%' : '');
          }
        }
      },
      y1: {
        type: 'linear',
        display: true,
        position: 'right',
        title: {
          display: true,
          text: 'Hours'
        },
        grid: {
          drawOnChartArea: false,
        },
        ticks: {
          callback: function(value) {
            return value + 'h';
          }
        }
      }
    }
  };

  return (
    <div className="h-64">
      <Bar data={chartData} options={options} />
    </div>
  );
};

export default YearComparisonChart;